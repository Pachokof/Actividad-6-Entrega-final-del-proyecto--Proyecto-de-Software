const config = {
  API_URL: "http://localhost:8080/v1/api",
  API_KEY: "your_api_key_here",
};

export { config };
